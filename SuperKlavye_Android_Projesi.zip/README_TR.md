# SüperKlavye — Android başlangıç projesi

## Neler var?
- Android'de gerçek giriş yöntemi (IME) olarak çalışan temel Türkçe klavye.
- Iron Man, Spider-Man, Hulk, Thor ve Avengers esintili renk hazır ayarları.
- Canlı önizleme, arka plan/tuş rengi değiştirme, temayı kaydetme.
- Tema renk kodlarını metin olarak paylaşma/dışa aktarma.
- Klavyeyi etkinleştirme ve varsayılan klavye seçme düğmeleri.

## Nasıl açılır?
1. Bilgisayarına Android Studio kur: https://developer.android.com/studio
2. Bu ZIP dosyasını çıkar.
3. Android Studio'da **Open** seçip `SuperKlavye` klasörünü aç.
4. Gradle eşitlemesinin bitmesini bekle.
5. Android telefonunu USB ile bağla (geliştirici seçenekleri/USB hata ayıklama açık) veya emülatör başlat.
6. **Run ▶** düğmesine bas.
7. Telefonda SüperKlavye uygulamasını aç.
8. **1. SüperKlavye'yi etkinleştir** düğmesine bas ve listeden SüperKlavye'yi aç.
9. Uygulamaya geri dönüp **2. Varsayılan klavyeyi seç** düğmesine bas; SüperKlavye'yi seç.
10. Herhangi bir mesajlaşma uygulamasında metin alanına dokunarak dene.

## Sınırlar
- Bu kaynak kodudur; hazır APK değildir. APK oluşturmak için Android Studio'da **Build > Build APK(s)** kullan.
- Marvel karakter adları yalnızca tema adlarında kullanılır; resmî Marvel görselleri/logoları pakete eklenmemiştir.
- Bu ilk sürümde arka plan görseli seçme, otomatik düzeltme, öneri çubuğu, tam büyük harf modu ve görsel PNG dışa aktarma yoktur.
- Klavye yazılan metni bu uygulamada saklamaz veya internete göndermez. Android klavyelerini yalnızca güvenilir kaynaklardan yükle.
