package com.superklavye

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout

class SuperKeyboardService : InputMethodService() {
    private val prefs by lazy { getSharedPreferences("theme", MODE_PRIVATE) }
    private var bg = Color.rgb(20,22,34)
    private var key = Color.rgb(190,35,48)
    private var ink = Color.WHITE

    override fun onCreateInputView(): View {
        bg = prefs.getInt("bg", bg); key = prefs.getInt("key", key); ink = prefs.getInt("ink", ink)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(3,5,3,5); setBackgroundColor(bg)
        }
        val rows = listOf(
            listOf("q","w","e","r","t","y","u","ı","o","p","ğ","ü"),
            listOf("a","s","d","f","g","h","j","k","l","ş","i"),
            listOf("⇧","z","x","c","v","b","n","m","⌫"),
            listOf("?123",",","🌐","boşluk",".","↵")
        )
        rows.forEachIndexed { index, rowKeys ->
            val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
            rowKeys.forEach { label ->
                val b = Button(this).apply {
                    text = if(label=="boşluk") "Türkçe" else label
                    textSize = if(label=="boşluk") 12f else 16f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(ink); setBackgroundColor(key)
                    isAllCaps = false; minWidth=0; minimumWidth=0
                    setPadding(0,0,0,0)
                    setOnClickListener { handle(label) }
                }
                val weight = if(label=="boşluk") 4f else if(label=="🌐" || label=="?123") 1.4f else 1f
                row.addView(b, LinearLayout.LayoutParams(0, 47, weight).apply {
                    setMargins(2,2,2,2)
                })
            }
            root.addView(row)
        }
        return root
    }

    private fun handle(label: String) {
        val ic = currentInputConnection ?: return
        when(label) {
            "⌫" -> ic.deleteSurroundingText(1,0)
            "↵" -> ic.commitText("\n",1)
            "boşluk" -> ic.commitText(" ",1)
            "⇧" -> { /* Bu başlangıç sürümünde büyük harf modu yok. */ }
            "?123" -> ic.commitText("123",1)
            "🌐" -> (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            else -> ic.commitText(label,1)
        }
    }
}
