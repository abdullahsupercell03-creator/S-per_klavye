package com.superklavye

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("theme", Context.MODE_PRIVATE) }
    private var bg = Color.rgb(20, 22, 34)
    private var key = Color.rgb(190, 35, 48)
    private var ink = Color.WHITE
    private lateinit var preview: LinearLayout
    private lateinit var status: TextView

    private val presets = listOf(
        Theme("Iron Man", Color.rgb(38, 20, 25), Color.rgb(200, 35, 45), Color.rgb(255, 220, 100)),
        Theme("Spider-Man", Color.rgb(15, 28, 58), Color.rgb(205, 35, 50), Color.WHITE),
        Theme("Hulk", Color.rgb(16, 42, 29), Color.rgb(48, 145, 67), Color.WHITE),
        Theme("Thor", Color.rgb(20, 29, 48), Color.rgb(65, 103, 160), Color.WHITE),
        Theme("Avengers", Color.rgb(19, 20, 29), Color.rgb(90, 75, 145), Color.WHITE)
    )
    data class Theme(val name: String, val bg: Int, val key: Int, val ink: Int)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bg = prefs.getInt("bg", bg); key = prefs.getInt("key", key); ink = prefs.getInt("ink", ink)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(10, 12, 20))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "🦸 SüperKlavye"; textSize = 28f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 8, 0, 4)
        }
        content.addView(title)
        content.addView(TextView(this).apply {
            text = "Marvel tarzı klavye temalarını oluştur"; textSize = 14f
            setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, 0, 0, 18)
        })
        content.addView(section("CANLI ÖNİZLEME"))
        preview = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(8, 10, 8, 10)
        }
        content.addView(preview)
        content.addView(section("HAZIR TEMALAR"))
        val gallery = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        presets.forEach { t ->
            val b = Button(this).apply {
                text = "✦ ${t.name} temasını uygula"
                setOnClickListener { bg=t.bg; key=t.key; ink=t.ink; renderPreview(); saveTheme(); status.text="${t.name} teması seçildi." }
            }
            gallery.addView(b)
        }
        content.addView(gallery)
        content.addView(section("KENDİ TEMANI OLUŞTUR"))
        content.addView(TextView(this).apply {
            text = "Arka plan rengi"; setTextColor(Color.WHITE); textSize=16f
        })
        content.addView(colorRow(listOf(
            "Gece" to Color.rgb(20,22,34), "Kırmızı" to Color.rgb(55,10,20),
            "Mavi" to Color.rgb(8,25,55), "Yeşil" to Color.rgb(8,42,25),
            "Mor" to Color.rgb(35,15,55)
        ), true))
        content.addView(TextView(this).apply {
            text = "Tuş rengi"; setTextColor(Color.WHITE); textSize=16f
        })
        content.addView(colorRow(listOf(
            "Kırmızı" to Color.rgb(200,35,45), "Altın" to Color.rgb(190,135,25),
            "Mavi" to Color.rgb(40,100,200), "Yeşil" to Color.rgb(48,145,67),
            "Mor" to Color.rgb(115,65,180), "Gri" to Color.rgb(70,75,90)
        ), false))
        content.addView(Button(this).apply {
            text = "💾 Temayı kaydet"
            setOnClickListener { saveTheme(); status.text="Tema bu telefona kaydedildi." }
        })
        content.addView(Button(this).apply {
            text = "📤 Temayı dışa aktar / paylaş"
            setOnClickListener {
                saveTheme()
                val share = Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_SUBJECT, "SüperKlavye temam")
                    .putExtra(Intent.EXTRA_TEXT, "SüperKlavye teması\nArka plan: ${colorHex(bg)}\nTuş: ${colorHex(key)}\nYazı: ${colorHex(ink)}")
                startActivity(Intent.createChooser(share, "Temayı paylaş"))
            }
        })
        content.addView(section("KLAVYEYİ ETKİNLEŞTİR"))
        content.addView(Button(this).apply {
            text = "1. SüperKlavye'yi etkinleştir"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        content.addView(Button(this).apply {
            text = "2. Varsayılan klavyeyi seç"
            setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        })
        status = TextView(this).apply {
            text = "İpucu: Klavyeyi etkinleştirdikten sonra bir metin kutusunda deneyebilirsin."
            setTextColor(Color.rgb(255, 215, 100)); textSize=14f; setPadding(0,12,0,12)
        }
        content.addView(status)
        content.addView(TextView(this).apply {
            text = "Not: Bu bağımsız bir başlangıç sürümüdür. Resmî Marvel görselleri içermez; renk temaları kullanır."
            setTextColor(Color.LTGRAY); textSize=12f; setPadding(0,8,0,20)
        })
        scroll.addView(content); root.addView(scroll); setContentView(root)
        renderPreview()
    }

    private fun section(s: String) = TextView(this).apply {
        text=s; textSize=13f; typeface=Typeface.DEFAULT_BOLD
        setTextColor(Color.rgb(255,205,70)); setPadding(0,18,0,8)
    }

    private fun colorRow(items: List<Pair<String,Int>>, background: Boolean): LinearLayout {
        val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        items.forEach { (name, c) ->
            row.addView(Button(this).apply {
                text=name; textSize=10f; setPadding(3,3,3,3)
                setOnClickListener { if(background) bg=c else key=c; renderPreview() }
            }, LinearLayout.LayoutParams(0, 48, 1f))
        }
        return row
    }

    private fun renderPreview() {
        if (!::preview.isInitialized) return
        preview.removeAllViews(); preview.setBackgroundColor(bg)
        val sample = TextView(this).apply {
            text="Süper kahraman klavyen"; setTextColor(ink); textSize=16f
            gravity=Gravity.CENTER; setPadding(0,0,0,8)
        }
        preview.addView(sample)
        listOf("Q W E R T Y U I O P", "A S D F G H J K L", "⇧ Z X C V B N M ⌫", "?123      ☺      Türkçe      ↵").forEach { line ->
            val row = TextView(this).apply {
                text=line; textSize=15f; gravity=Gravity.CENTER; setTextColor(ink)
                setBackgroundColor(key); setPadding(4,10,4,10)
            }
            val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(2,3,2,3); preview.addView(row, lp)
        }
    }

    private fun saveTheme() {
        prefs.edit().putInt("bg",bg).putInt("key",key).putInt("ink",ink).apply()
    }
    private fun colorHex(c: Int) = String.format("#%06X", 0xFFFFFF and c)
}
